"use strict";

import {

    auth,

    database,

    ref,

    get

} from "./firebase.js";

import {

    signInWithEmailAndPassword,

    signOut,

    onAuthStateChanged

} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

import {

    FIREBASE_PATHS,

    DASHBOARD_URL

} from "./config.js";

/* Login View */

const loginView = document.getElementById("login-view");

/* Dashboard View */

const dashboardView = document.getElementById("dashboard-view");

/* Login Form */

const loginForm = document.getElementById("login-form");

/* Email */

const emailInput = document.getElementById("email");

/* Password */

const passwordInput = document.getElementById("password");

/* Login Message */

const loginMessage = document.getElementById("login-message");

/* Status */

const extensionStatus = document.getElementById("extension-status");

/* Schedule */

const scheduleStart = document.getElementById("schedule-start");

const scheduleEnd = document.getElementById("schedule-end");

/* Blocked Sites */

const blockedSitesCount = document.getElementById("blocked-sites-count");

/* Buttons */

const openDashboardButton = document.getElementById("open-dashboard-btn");

const logoutButton = document.getElementById("logout-btn");



/* Initialize */

initializePopup();

/* Initialize Popup */

function initializePopup() {

    onAuthStateChanged(

        auth,

        async (user) => {

            if (!user) {

                showLoginView();

                return;

            }

            showDashboardView();

            await loadDashboardData(user.uid);

        }

    );

    loginForm.addEventListener(

        "submit",

        handleLogin

    );

    logoutButton.addEventListener(

        "click",

        handleLogout

    );

    openDashboardButton.addEventListener(

        "click",

        openDashboard

    );

}

/* Login */

async function handleLogin(event) {

    event.preventDefault();

    loginMessage.textContent = "";

    try {

        await signInWithEmailAndPassword(

            auth,

            emailInput.value.trim(),

            passwordInput.value

        );

    }

    catch (error) {

        loginMessage.textContent = error.message;

    }

}

/* Logout */

async function handleLogout() {

    await signOut(auth);

}

/* Load Dashboard Data */

async function loadDashboardData(uid) {

    const settingsSnapshot = await get(

        ref(

            database,

            `${FIREBASE_PATHS.SETTINGS}/${uid}`

        )

    );

    if (settingsSnapshot.exists()) {

        const settings = settingsSnapshot.val();

        extensionStatus.textContent = settings.enabled

            ? "Protection Enabled"

            : "Protection Disabled";

        scheduleStart.textContent = settings.startTime;

        scheduleEnd.textContent = settings.endTime;

    }

    const blockedSnapshot = await get(

        ref(

            database,

            `${FIREBASE_PATHS.BLOCKED_SITES}/${uid}`

        )

    );

    if (blockedSnapshot.exists()) {

        blockedSitesCount.textContent =

            Object.keys(blockedSnapshot.val()).length;

    }

    else {

        blockedSitesCount.textContent = "0";

    }

}

/* Open Dashboard */

function openDashboard() {

    chrome.tabs.create({

        url: DASHBOARD_URL

    });

}

/* Show Login */

function showLoginView() {

    loginView.hidden = false;

    dashboardView.hidden = true;

}

/* Show Dashboard */

function showDashboardView() {

    loginView.hidden = true;

    dashboardView.hidden = false;

}